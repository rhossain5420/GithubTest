

public class Meal {
    public String strMeal;
    public String strCategory;
    public String strArea;
    public String strIngredient1;
    public String strIngredient2;
    public String strIngredient3;
    public String strIngredient4;
    public String strIngredient5;
    public String strIngredient6;
    public String strIngredient7;
    public String strIngredient8;
    public String strIngredient9;
    public String strIngredient10;
    public String strIngredient11;
    public String strIngredient12;
    public String strIngredient13;
    public String strIngredient14;
    public String strIngredient15;
    public String strIngredient16;
    public String strIngredient17;
    public String strIngredient18;
    public String strIngredient19;
    public String strIngredient20;
    
    public Meal(String strMeal, String strCategory, String strArea) {
        this.strMeal = strMeal;
        this.strCategory = strCategory;
        this.strArea = strArea;
    }

//     public String getStrMeal() {
//         return strMeal;
//     }
// 
//     public void setStrMeal(String strMeal) {
//         this.strMeal = strMeal;
//     }
// 
//     public String getStrCategory() {
//         return strCategory;
//     }
// 
//     public void setStrCategory(String strCategory) {
//         this.strCategory = strCategory;
//     }
// 
//     public String getStrArea() {
//         return strArea;
//     }
// 
//     public void setStrArea(String strArea) {
//         this.strArea = strArea;
//     }
    public String toString() {
        return 
                "MealName = " + strMeal + "\n" +
                "Type of Meal = " + strCategory + "\n" +
                "Counrty of Meal = " + strArea + "\n" +
                "Ingredient 1: = " + strIngredient1 + "\n" +
                "Ingredient 2: = " + strIngredient2 + "\n" +
                "Ingredient 3: = " + strIngredient3 + "\n" +
                "Ingredient 4: = " + strIngredient4 + "\n" +
                "Ingredient 5: = " + strIngredient5 + "\n" +
                "Ingredient 6: = " + strIngredient6 + "\n" +
                "Ingredient 7: = " + strIngredient7 + "\n" +
                "Ingredient 8: = " + strIngredient8 + "\n" +
                "Ingredient 9: = " + strIngredient9 + "\n" +
                "Ingredient 10: = " + strIngredient10 + "\n" +
                "Ingredient 11: = " + strIngredient11 + "\n" +
                "Ingredient 12: = " + strIngredient12 + "\n" +
                "Ingredient 13: = " + strIngredient13 + "\n" +
                "Ingredient 14: = " + strIngredient14 + "\n" +
                "Ingredient 15: = " + strIngredient15 + "\n" +
                "Ingredient 16: = " + strIngredient16 + "\n" +
                "Ingredient 17: = " + strIngredient17 + "\n" +
                "Ingredient 18: = " + strIngredient18 + "\n" +
                "Ingredient 19: = " + strIngredient19 + "\n" +
                "Ingredient 20: = " + strIngredient20;
    }
    
}
