public class ApiData
{

 public Meals[] meals;

}