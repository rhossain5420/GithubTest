public class Meals
{
 private String strMeal;
 private String idMeal;
 private String strMealThumb;

 public Meals(String strMeal, String idMeal, String strMealThumb)
 {
 this.strMeal = strMeal;
 this.idMeal = idMeal;
 this.strMealThumb = strMealThumb;
 }
  
 public void setStrMeal(String strMeal)
 {
 this.strMeal = strMeal;
 }
 
  public void setStrMealThumb(String strMealThumb)
 {
 this.strMealThumb = strMealThumb;
 }

 public void setIdMeal(String idMeal)
 {
 this.idMeal = idMeal;
 }

public String getStrMeal()
 {
 return strMeal;
 }
 
  public String getStrMealThumb()
 {
 return strMealThumb;
 }

 public String getIdMeal()
 {
 return idMeal;
 }

 
 }

 