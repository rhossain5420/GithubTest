import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class ReciNationController {

    @FXML
    private Label Instructions;

    @FXML
    private SplitPane Scene;

    @FXML
    private Label Title;

    @FXML
    private AnchorPane firstBackground;

    @FXML
    private ImageView foodImage;

    @FXML
    private AnchorPane secondBackground;

    @FXML
    void generateRecipes(ActionEvent event) {
    layout.getChildren().addAll(generateButton, mealLabel);
    }

}
