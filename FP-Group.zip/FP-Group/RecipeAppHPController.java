import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.layout.AnchorPane;

public class RecipeAppHPController {

    @FXML
    private Label A;

    @FXML
    private ImageView PIC;

    @FXML
    private Label PLAY;

    @FXML
    private AnchorPane RecipeWind;

    @FXML
    private Label TEXT1;

    @FXML
    void click(ActionEvent event) {

    }

    @FXML
    void sub(DragEvent event) {

    }

}


